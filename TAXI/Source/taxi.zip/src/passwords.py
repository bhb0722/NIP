class Passwords(object):

    LOCAL_MYSQL_HOST = "127.0.0.1"
    LOCAL_MYSQL_USER = "root"
    LOCAL_MYSQL_PASSWORD = "michael21"

    # NOTE: Update these credentials with your remote account details, but do
    # not push sensitive account details.
    REMOTE_MYSQL_HOST = ""
    REMOTE_MYSQL_USER = ""
    REMOTE_MYSQL_PASSWORD = ""
